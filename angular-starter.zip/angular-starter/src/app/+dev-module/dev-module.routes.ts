import { DevModuleComponent } from './dev-module.component';

export const routes = [
  { path: 'dev-module', component: DevModuleComponent }
];
